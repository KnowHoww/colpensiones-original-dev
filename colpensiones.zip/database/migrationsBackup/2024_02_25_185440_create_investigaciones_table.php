<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('investigaciones', function (Blueprint $table) {
            $table->id();
            $table->string('MarcaTemporal');
            $table->string('NumeroRadicacionCaso', 50);
            $table->integer('IdCase');
            $table->bigInteger('TipoInvestigacion')->unsigned()->nullable();
            $table->bigInteger('TipoRiesgo')->unsigned()->nullable();
            $table->bigInteger('DetalleRiesgo')->unsigned()->nullable();
            $table->bigInteger('TipoTramite')->unsigned()->nullable();
            $table->bigInteger('TipoSolicitud')->unsigned()->nullable();
            $table->bigInteger('TipoSolicitante')->unsigned()->nullable();
            $table->bigInteger('TipoPension')->unsigned()->nullable();
            $table->bigInteger('TipoDocumento')->unsigned()->nullable();
            $table->string('NumeroDeDocumento', 12)->nullable();
            $table->string('PrimerNombre', 50)->nullable();
            $table->string('SegundoNombre', 50)->nullable();
            $table->string('PrimerApellido', 50)->nullable();
            $table->string('SegundoApellido', 50)->nullable();
            $table->string('RadicadoAsociado', 50)->nullable();
            $table->string('Solicitud', 200)->nullable();
            $table->string('investigador', 50)->nullable();
            $table->string('TelefonoCausante', 50)->nullable();
            $table->string('Ciudad', 50)->nullable();
            $table->string('DireccionCausante', 50)->nullable();
            $table->string('analista', 50)->nullable();
            $table->string('estado', 50)->nullable();
            $table->string('Prioridad', 50)->nullable();
            $table->string('Junta', 50)->nullable();
            $table->string('NumeroDictamen', 50)->nullable();
            $table->string('FechaDictamen', 50)->nullable();
            $table->text('Observacion')->nullable();
            $table->string('PuntoAtencion', 200)->nullable();
            $table->string('DireccionPunto', 200)->nullable();
            $table->timestamp('Fecha_finalizacion')->nullable();
            $table->timestamps();

            //$table->foreign('TipoInvestigacion')->references('id')->on('tipo_investigacion');
            //$table->foreign('TipoRiesgo')->references('id')->on('tipo_riesgo');
            //$table->foreign('DetalleRiesgo')->references('id')->on('detalle_riesgo');
            //$table->foreign('TipoTramite')->references('id')->on('tipo_tramite');
            //$table->foreign('TipoSolicitud')->references('id')->on('tipo_solicitud');
            //$table->foreign('TipoSolicitante')->references('id')->on('tipo_solicitante');
            //$table->foreign('TipoPension')->references('id')->on('tipo_investigacion');
            //$table->foreign('TipoDocumento')->references('id')->on('tipo_investigacion');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('investigaciones');
    }
};
