<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('investigacion_auxilio_funerarios', function (Blueprint $table) {
            $table->id();
            $table->string('valorGastosFunerarios');
            $table->string('tipoPago');
            $table->string('personaSufrago');
            $table->string('detalleServicio');
            $table->string('cesionDerechos');
            $table->string('personaCesionDerechos');
            $table->string('personaDocumento');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('investigacion_auxilio_funerarios');
    }
};
