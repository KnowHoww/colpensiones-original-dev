<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('investigacion_consultas_antecedentes_causante', function (Blueprint $table) {
            $table->id();
            $table->string('idInvestigacion');
            $table->string('adres');
            $table->string('ruaf');
            $table->string('rues');
            $table->string('rnec');
            $table->string('cufe');
            $table->string('sispro');
            $table->string('rama_judicial');
            $table->string('samai');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('investigacion_consultas_antecedentes_causante');
    }
};
