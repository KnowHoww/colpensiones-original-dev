<?php
setlocale(LC_TIME, 'es_ES.UTF-8');

$order   = array("\r\n", "\n", "\r", "<p>");
$replace = '<br />';

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>{{ $nombre }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
    </style>

    <style>
        .roboto-thin {
            font-family: "Roboto", sans-serif;
            font-weight: 100;
            font-style: normal;
        }

        .roboto-light {
            font-family: "Roboto", sans-serif;
            font-weight: 300;
            font-style: normal;
        }

        .roboto-regular {
            font-family: "Roboto", sans-serif;
            font-weight: 400;
            font-style: normal;
        }

        .roboto-medium {
            font-family: "Roboto", sans-serif;
            font-weight: 500;
            font-style: normal;
        }

        .roboto-bold {
            font-family: "Roboto", sans-serif;
            font-weight: 700;
            font-style: normal;
        }

        .roboto-black {
            font-family: "Roboto", sans-serif;
            font-weight: 900;
            font-style: normal;
        }

        .roboto-thin-italic {
            font-family: "Roboto", sans-serif;
            font-weight: 100;
            font-style: italic;
        }

        .roboto-light-italic {
            font-family: "Roboto", sans-serif;
            font-weight: 300;
            font-style: italic;
        }

        .roboto-regular-italic {
            font-family: "Roboto", sans-serif;
            font-weight: 400;
            font-style: italic;
        }

        .roboto-medium-italic {
            font-family: "Roboto", sans-serif;
            font-weight: 500;
            font-style: italic;
        }

        .roboto-bold-italic {
            font-family: "Roboto", sans-serif;
            font-weight: 700;
            font-style: italic;
        }

        .roboto-black-italic {
            font-family: "Roboto", sans-serif;
            font-weight: 900;
            font-style: italic;
        }

        .table-head .tr,
        th,
        td {
            border: 3px solid #011837;
            font-family: "Roboto", sans-serif;
            font-weight: 700;
            font-style: normal;
            padding: 2px 5px;
        }

        .border-table {
            border: 1px solid #000000;
            border-top: 0px solid transparent;
            font-family: "Roboto", sans-serif;
            padding: 2px 5px;
        }

        .border-table p {
            margin: 0px;
            border: 0px solid transparent !important;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 170px;
            margin-top: 0px;
            background-color: #fff;
            font-family: "Roboto", sans-serif;
            font-weight: 700;
            font-style: normal;
            line-height: 1.4;
        }

        .content {
            /* margin-top: 180px; */
        }

        .table-body tr,
        th,
        td {
            border: 1px solid black;
            font-family: "Roboto", sans-serif;
            font-weight: 400;
            font-style: normal;
            padding: 2px 5px;
        }

        .logo {
            width: 100px;
            padding: 5px;
            align-content: center;
            align-items: center;
            justify-content: center;
            vertical-align: middle;
        }

        .logo img {
            height: 20px;
        }

        .bg-primary {
            background: #dbe5f1 !important;
            text-align: center;
            font-weight: 700;
        }

        table {
            width: 100%;
            font-family: "Roboto", sans-serif;
            font-weight: 400;
            font-style: normal;
        }

        * {
            font-size: 13px !important;
            word-wrap: break-word;
        }

        .text-left {
            text-align: left !important;
        }

 		.text-justify {
            text-align:  justify !important;
        }

        .section {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

<?php
if (!function_exists('clean_text1')) {
    function clean_text1($text) {
    if (!mb_check_encoding($text, 'UTF-8')) {
        $text = mb_convert_encoding($text, 'UTF-8', 'auto');
    }
    $text = strip_tags($text,"<b><i><br><ul><li><p>");
    // Eliminar caracteres especiales invisibles o no imprimibles
    //$text = preg_replace('/[\x00-\x1F\x7F\xA0\xAD\x{200B}-\x{200D}\x{FEFF}]/u', '', $text);
    $text = preg_replace('/[\x00-\x1F\x7F\xA0\xAD\x{200B}-\x{200D}\x{FEFF}]/u', ' ', $text);

    // Reemplazar espacios no estándar por espacios normales
    $text = preg_replace('/\s+/u', ' ', $text);

    // Reemplazar el carácter ● con un bullet estándar en HTML
    $text = preg_replace('/●/', '<li>', $text);
    
    // Cerrar los bullets reemplazados
    $text = preg_replace('/<\/span><\/p>/', '</li></span></p>', $text);

        // Eliminar solo las etiquetas de table, mantener el contenido interno
           // Eliminar etiquetas de apertura y cierre de tabla, pero conservar el contenido interno
           $text = preg_replace('/<table\b[^>]*>/i', '', $text);
           $text = preg_replace('/<\/table>/i', '', $text);
           $text = preg_replace('/<tbody\b[^>]*>/i', '', $text);
           $text = preg_replace('/<\/tbody>/i', '', $text);
           $text = preg_replace('/<tr\b[^>]*>/i', '', $text);
           $text = preg_replace('/<\/tr>/i', '', $text);
           $text = preg_replace('/<td\b[^>]*>/i', '', $text);
           $text = preg_replace('/<\/td>/i', '', $text);

                // Eliminar solo los atributos de estilo y clase, pero conservar las etiquetas <span> y <font>
            $text = preg_replace('/(<span\b[^>]*)style=["\'][^"\']*["\']([^>]*>)/i', '$1$2', $text);
            $text = preg_replace('/(<span\b[^>]*)class=["\'][^"\']*["\']([^>]*>)/i', '$1$2', $text);
            $text = preg_replace('/(<font\b[^>]*)face=["\'][^"\']*["\']([^>]*>)/i', '$1$2', $text);
            $text = preg_replace('/(<font\b[^>]*)color=["\'][^"\']*["\']([^>]*>)/i', '$1$2', $text);
            $text = preg_replace('/(<p\b[^>]*)style=["\'][^"\']*["\']([^>]*>)/i', '$1$2', $text);

             // Agrupar los <li> en una lista <ul> si no están agrupados
    $text = preg_replace('/(<li>.*?<\/li>)/is', '<ul>$1</ul>', $text);

            // Corregir posibles problemas con múltiples listas
        $text = preg_replace('/<\/ul>\s*<ul>/i', '', $text);

        // Añadir estilo de justificación a los párrafos
        $text = preg_replace('/<p\b([^>]*)>/i', '<p$1 style="text-align: justify;">', $text);

        return $text;
    }
    
}

// Obtener y filtrar el texto
$text = $entrevistaSolicitante->trabajo_campo;
$filtered_text =clean_text1($text) ;

?>
    

    <div class="headers">
        <table class="table datatable table-head">
            <thead>
                <tr>
                    <th rowspan="2" class="logo"><img src="../public/images/logo_javh.png" /></th>
                    <th class="text-center roboto-bold">Gestión de proyecto</th>
                    <th class="text-center roboto-bold">Página de </th>
                </tr>
                <tr>
                    <th class="text-center roboto-bold">Informe Técnico Investigaciones Administrativas</th>
                    <th class="text-center roboto-bold">Versión 01</th>
                </tr>
                <tr>
                    <th colspan="3" class="roboto-bold">Nombre del Proyecto: Investigaciones Administraciones
                        Colpensiones</th>
                </tr>
                <tr>
                    <th colspan="3" class="roboto-bold">Contrato 004 de 2024 celebrado entre La Administradora
                        Colombiana de Pensiones -
                        Colpensiones y Jahv McGregor</th>
                </tr>
                <tr>
                    <th colspan="3" class="roboto-bold">Título: Informe Técnico Investigaciones Administrativas</th>
                </tr>
            </thead>
        </table>
    </div>

    <div class="content">


        <div class="section">
            <table class="table-body">
                <tr>
                    <th class="bg-primary" colspan="4">INFORMACIÓN DEL CASO</th>
                </tr>
                @if ($investigacion->esObjetado == 1)
                    <tr>
                        <th>Versión objeción</th>
                        <th>Fecha objeción</th>
                        <th>Fecha aprobación objeción</th>
                        <th>Fecha finalización objeción</th>
                    </tr>
                    <tr>
                        <td>{{ $investigacion->cantidadObjeciones }}</td>
                        <td>{{ date('Y-m-d H:i:s', strtotime($investigacion->FechaObjecion)) }}</td>
                        <td>{{ date('Y-m-d H:i:s', strtotime($investigacion->FechaAprobacionObjecion)) }}</td>
                        <td>{{ date('Y-m-d H:i:s', strtotime($investigacion->FechaFinalizacionObjecion)) }}</td>
                    </tr>
                @endif
                <tr>
                    <th colspan="2">Centro de costos</th>
                    <td colspan="2">{{ optional($investigacion->CentroCostos)->nombre }}</td>
                </tr>
                <tr>
                    <th>Número de radicado</th>
                    <td>{{ $investigacion->CasoPadreOriginal }}</td>
                    <th>ID del caso</th>
                    <td>{{ $investigacion->IdCase }}</td>
                </tr>
                <tr>
                    <th>Departamento de verificación</th>
                    <td>{{ optional($investigacion->departamentos)->departamento }}</td>
                    <th>Municipio de verificación</th>
                    <td>{{ optional($investigacion->municipios)->municipio }}</td>
                </tr>
                <tr>
                    <th>Fecha de resultado</th>
                    <td>{{ date('Y-m-d H:i:s', strtotime($investigacion->FechaFinalizacion)) }}</td>
                    <th>Fecha de recibo de la solicitud</th>
                    <td>{{ $investigacion->FechaAprobacion}}</td>
                </tr>
                <tr>
                    <th>Nombre del causante</th>
                    <td>
                        {{ ucfirst($investigacion->PrimerNombre ?? '') }}
                        {{ ucfirst($investigacion->SegundoNombre ?? '') }}
                        {{ ucfirst($investigacion->PrimerApellido ?? '') }}
                        {{ ucfirst($investigacion->SegundoApellido ?? '') }}
                    </td>
                    <th>Identificación</th>
                    <td>{{ $investigacion->NumeroDeDocumento }}</td>
                </tr>
                <tr>
                    <th>Tipo de investigación</th>
                    <td>{{ optional($investigacion->TipoInvestigaciones)->nombre }}</td>
                    <th>Tipo de riesgo</th>
                    <td>{{ optional($investigacion->TipoRiesgos)->nombre }}</td>
                </tr>
                <tr>
                    <th>Objeto de investigación</th>
                    <td colspan="3">{{ $investigacion->Observacion }}</td>
                </tr>
            </table>
        </div>

        @if ($secciones->contains('nombre', 'DatosVerificacion'))
            <div class="section">
                <table class="table-body">
                    <thead>
                        <tr>
                            <th class="bg-primary">NOMBRE DE SOLICITANTES</th>
                            <th class="bg-primary">TIPO DE DOCUMENTO</th>
                            <th class="bg-primary">NÚMERO DE DOCUMENTO</th>
                            <th class="bg-primary">CIUDAD</th>
                            <th class="bg-primary">DIRECCIÓN</th>
                            <th class="bg-primary">TELÉFONO</th>
                            <th class="bg-primary">PARENTESCO</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($investigacionVerificacion as $item)
                            <tr>
                                <td>{{ $item->PrimerNombre }} {{ $item->SegundoNombre }} {{ $item->PrimerApellido }}
                                    {{ $item->SegundoApellido }}</td>
                                <td>{{ $item->TipoDocumento }}</td>
                                <td>{{ $item->NumeroDocumento }}</td>
                                <td>{{ $item->ciudad }}</td>
                                <td>{{ $item->direccion }}</td>
                                <td>{{ $item->telefono }}</td>
                                <td>{{ $item->parentesco }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif

        @if ($secciones->contains('nombre', 'ValidacionDocumental'))
            <div class="section">
                <table class="table-body">
                    <tr>
                        <th colspan="2" class="bg-primary ">VALIDACIÓN DOCUMENTAL</th>
                    </tr>
                    <tr>
                        <th colspan="2" class="roboto-bold">VALIDACIÓN DOCUMENTAL DEL CAUSANTE</th>
                    </tr>
                    @if ($validacionDocumentalCausante->cedula != '')
                        <tr>
                            <td>CÉDULA DE CIUDADANÍA</td>
                            <td><?php echo strip_tags($validacionDocumentalCausante->cedula); ?></td>
                        </tr>
                    @endif
                    @if ($validacionDocumentalCausante->defuncion != '')
                        <tr>
                            <td>REGISTRO CIVIL DE DEFUNCIÓN</td>
                            <td><?php echo strip_tags($validacionDocumentalCausante->defuncion); ?></td>
                        </tr>
                    @endif
                    @if ($validacionDocumentalCausante->matrimonio != '')
                        <tr>
                            <td>REGISTRO CIVIL DE MATRIMONIO </td>
                            <td><?php echo clean_text1($validacionDocumentalCausante->matrimonio); ?></td>
                        </tr>
                    @endif
                    @if ($validacionDocumentalCausante->gastos_funebre != '')
                        <tr>
                            <td>EVIDENCIA GASTOS FÚNEBRES</td>
                            <td><?php echo clean_text1($validacionDocumentalCausante->gastos_funebre); ?></td>
                        </tr>
                    @endif
                    @if ($validacionDocumentalCausante->gastos_funerarios != '')
                        <tr>
                            <td>EVIDENCIA GASTOS FUNERARIOS</td>
                            <td><?php echo clean_text1($validacionDocumentalCausante->gastos_funerarios); ?></td>
                        </tr>
                    @endif
                    <tr>
                        <th colspan="2" class="roboto-bold">VALIDACIÓN DOCUMENTAL DEL SOLICITANTE</th>
                    </tr>
                    @foreach ($validacionDocumentalBeneficiarios as $item)
                        <tr>
                            <th class="roboto-bold-italic" colspan="2">{{ $item->PrimerNombre }}
                                {{ $item->SegundoNombre }}
                                {{ $item->PrimerApellido }} {{ $item->SegundoApellido }}</th>
                        </tr>
                        @if ($item->cedula != '')
                            <tr>
                                <th>CÉDULA DE CIUDADANÍA</th>
                                <td><?php echo clean_text1($item->cedula); ?></td>
                            </tr>
                        @endif
                        @if ($item->nacimiento != '')
                            <tr>
                                <th>REGISTRO CIVIL DE NACIMIENTO</th>
                                <td><?php echo clean_text1($item->nacimiento); ?></td>
                            </tr>
                        @endif
                        @if ($item->incapacidad != '')
                            <tr>
                                <th>DICTAMEN MÉDICO DE INCAPACIDAD LABORAL </th>
                                <td><?php echo clean_text1($item->incapacidad); ?></td>
                            </tr>
                        @endif
                        @if ($item->escolaridad != '')
                            <tr>
                                <th>CERTIFICADO DE ESCOLARIDAD</th>
                                <td><?php echo clean_text1($item->escolaridad); ?></td>
                            </tr>
                        @endif
                    @endforeach
                </table>
            </div>
        @endif

        @if ($secciones->contains('nombre', 'ConsultaBaseDatos'))
            <div class="section">
                <table class="table-body">
                    <tr>
                        <th colspan="2" class="bg-primary ">CONSULTA BASES DE DATOS</th>
                    </tr>
                    <tr>
                        <th colspan="2" class="roboto-bold">CAUSANTE</th>
                    </tr>
                    @if ($AntecedentesCausante->adres == 12)
                        <tr>
                            <th>ADRES</th>
                            <td>{{ $AntecedentesCausante->observacion_adres }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->ruaf == 12)
                        <tr>
                            <th>RUAF</th>
                            <td>{{ $AntecedentesCausante->observacion_ruaf }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->rues == 12)
                        <tr>
                            <th>RUES</th>
                            <td>{{ $AntecedentesCausante->observacion_rues }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->rnec == 12)
                        <tr>
                            <th>RNEC</th>
                            <td>{{ $AntecedentesCausante->observacion_rnec }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->cufe == 12)
                        <tr>
                            <th>CUFE</th>
                            <td>{{ $AntecedentesCausante->observacion_cufe }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->sispro == 12)
                        <tr>
                            <th>SISPRO</th>
                            <td>{{ $AntecedentesCausante->observacion_sispro }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->rama_judicial == 12)
                        <tr>
                            <th>RAMA JUDICIAL</th>
                            <td>{{ $AntecedentesCausante->observacion_rama_judicial }}</td>
                        </tr>
                    @endif
                    @if ($AntecedentesCausante->samai == 12)
                        <tr>
                            <th>SAMAI</th>
                            <td>{{ $AntecedentesCausante->observacion_samai }}</td>
                        </tr>
                    @endif
                    <tr>
                        <th colspan="2" class="roboto-bold">SOLICITANTE(S)</th>
                    </tr>
                    @foreach ($antecedentesBeneficiarios as $item)
                        <tr>
                            <th class="roboto-bold-italic" colspan="2">{{ $item->PrimerNombre }}
                                {{ $item->SegundoNombre }}
                                {{ $item->PrimerApellido }} {{ $item->SegundoApellido }}</th>
                        </tr>
                        @if ($item->adres == 12)
                            <tr>
                                <th>ADRES</th>
                                <td>{{ $item->observacion_adres }}</td>
                            </tr>
                        @endif
                        @if ($item->ruaf == 12)
                            <tr>
                                <th>RUAF</th>
                                <td>{{ $item->observacion_ruaf }}</td>
                            </tr>
                        @endif
                        @if ($item->rues == 12)
                            <tr>
                                <th>RUES</th>
                                <td>{{ $item->observacion_rues }}</td>
                            </tr>
                        @endif
                        @if ($item->rnec == 12)
                            <tr>
                                <th>RNEC</th>
                                <td>{{ $item->observacion_rnec }}</td>
                            </tr>
                        @endif
                        @if ($item->cufe == 12)
                            <tr>
                                <th>CUFE</th>
                                <td>{{ $item->observacion_cufe }}</td>
                            </tr>
                        @endif
                        @if ($item->sispro == 12)
                            <tr>
                                <th>SISPRO</th>
                                <td>{{ $item->observacion_sispro }}</td>
                            </tr>
                        @endif
                        @if ($item->rama_judicial == 12)
                            <tr>
                                <th>RAMA JUDICIAL</th>
                                <td>{{ $item->observacion_rama_judicial }}</td>
                            </tr>
                        @endif
                        @if ($item->samai == 12)
                            <tr>
                                <th>SAMAI</th>
                                <td>{{ $item->observacion_samai }}</td>
                            </tr>
                        @endif
                    @endforeach
                </table>
            </div>
        @endif

        @if ($secciones->contains('nombre', 'TrazabilidadActividades'))
            <div class="section">
                <table class="table-body">
                    <thead>
                        <tr>
                            <th colspan="3" class="bg-primary">
                                TRAZABILIDAD DE LAS ACTIVIDADES REALIZADAS
                            </th>
                        </tr>
                        <tr>
                            <th class="roboto-bold text-center">ACTIVIDAD REALIZADA</th>
                            <th class="roboto-bold text-center">OBSERVACIÓN</th>
                            <th class="roboto-bold text-center">FECHA</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($trazabilidadActividades as $item)
                            <tr>
                                <td>{{ $item->actividad }}</td>
                                <td>{{ $item->observacion }}</td>
                                <td>@if (!is_null($item->fecha))
                                            {{ $item->fecha}}       
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif

        <div class="section">
            @if ($entrevistaSolicitante->trabajo_campo != '')
                <table class="table-body">
                    <thead>
                        <tr>
                            <th class="bg-primary">TRABAJO DE INVESTIGACIÓN REALIZADO</th>
                        </tr>
                        <tr>
                            <th class="bg-primary roboto-bold text-left">ENTREVISTA A SOLICITANTE</th>
                        </tr>
                    </thead>
                </table>
                <div class="border-table">
                    <p class="text-break"><?php echo $filtered_text; ?></p>
                </div>
            @endif
            @if ($gastosVivienda->totalValor != 0 && $gastosVivienda->totalValor != null)
                <div>
                    <table>
                        <tr>
                            <table>
                                <tr>
                                    <th class="bg-primary" colspan="3">GASTOS DE LA VIVIENDA</th>
                                </tr>
                                <tr>
                                    <th class="bg-primary" colspan="2">Total gastos del hogar</th>
                                    <th class="bg-primary">Aportes del afiliado a los gastos del hogar</th>
                                </tr>
                                <tr>
                                    <th class="text-center">Concepto</th>
                                    <th class="text-center">Valor</th>
                                    <th class="text-center">Valor</th>
                                </tr>
                                <tr>
                                    <th class="">Servicios Públicos</th>
                                    <th class="text-center">
                                        {{ number_format($gastosVivienda->serviciosPublicosValor) }}</th>
                                    <th class="text-center">
                                        {{ number_format($gastosVivienda->serviciosPublicosValorAporte) }}</th>
                                </tr>
                                <tr>
                                    <th class="">Arriendo</th>
                                    <th class="text-center">{{ number_format($gastosVivienda->arriendoValor) }}</th>
                                    <th class="text-center">{{ number_format($gastosVivienda->arriendoValorAporte) }}
                                    </th>
                                </tr>
                                <tr>
                                    <th class="">Mercado</th>
                                    <th class="text-center">{{ number_format($gastosVivienda->mercadoValor) }}</th>
                                    <th class="text-center">{{ number_format($gastosVivienda->mercadoValorAporte) }}
                                    </th>
                                </tr>
                                <tr>
                                    <th class="">Otros</th>
                                    <th class="text-center">{{ number_format($gastosVivienda->otrosValor) }}</th>
                                    <th class="text-center">{{ number_format($gastosVivienda->otrosValorAporte) }}</th>
                                </tr>
                                <tr>
                                    <th class="text-center bg-primary">Total</th>
                                    <th class="text-center bg-primary">{{ number_format($gastosVivienda->totalValor) }}
                                    </th>
                                    <th class="text-center bg-primary">
                                        {{ number_format($gastosVivienda->totalValorAporte) }}</th>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <?php echo  strip_tags($gastosVivienda->observacion,"<b><i><br>"); ?>
                                    </td>
                                </tr>
                            </table>
                        </tr>
                    </table>
                </div>
            @endif
            @if ( !empty($laborCampo->laborCampo))
                <table>
                    <tr>
                        <th class="bg-primary roboto-bold text-left">LABOR DE CAMPO</th>
                    </tr>
                </table>
                <div class="border-table">
                    <p class="text-break"><?php echo  clean_text1( $laborCampo->laborCampo); ?></p>
                </div>
            @endif
            @if ($entrevistaFamiliares->laborCampo != '')
                <table>
                    <tr>
                        <th class="bg-primary roboto-bold text-left">ENTREVISTA A FAMILIARES DEL CAUSANTE</th>
                    </tr>
                </table>
                <div class="border-table">
                    <p class="text-break"><?php echo  strip_tags($entrevistaFamiliares->laborCampo,"<b><i><br>"); ?></p>
                </div>
            @endif
            @if ($estudioAuxiliar->labor != '')
                <div>
                    <table>
                        <tr>
                            <th class="bg-primary roboto-bold text-left">ESTUDIOS AUXILIARES (GRAFOLOGÍA,
                                DACTILOSCOPIA,
                                BIOMETRÍA) </th>
                        </tr>

                    </table>
                    <div class="border-table">
                        <p class="text-break"><?php echo strip_tags($estudioAuxiliar->labor,"<b><i><br>"); ?></p>
                    </div>

                </div>
            @endif
            @if ($estudioAuxiliar->entrevistaExtrajuicio != '')
                <table>
                    <tr>
                        <th class="bg-primary roboto-bold text-left">ENTREVISTA A DECLARANTES EXTRAJUICIO</th>
                    </tr>
                </table>
                <div class="border-table">
					>
                    <p class="text-break"><?php echo strip_tags($estudioAuxiliar->entrevistaExtrajuicio,"<b><i><br>"); ?></p>
                </div>
            @endif
            @if ($estudioAuxiliar->hallazgos != '' || $estudioAuxiliar->observacion != '')
                <div>
                    <table>
                        <tr>
                            <th class="bg-primary roboto-bold text-left">HALLAZGOS ADICIONALES EN EL PROCESO DE
                                INVESTIGACIÓN</th>
                        </tr>
                    </table>
                    <div class="border-table">
                    	<p class="text-break"><?php echo clean_text1($estudioAuxiliar->hallazgos,"<b><i><br><ul><li>"); ?></p>
                        
                    </div>
                    @if ($estudioAuxiliar->observacion != '')
                        <div class="border-table">
                            <p class="text-break"><?php echo clean_text1($estudioAuxiliar->observacion,"<b><i><br><ul><li>"); ?></p>
                        </div>
                    @endif
                </div>
            @endif
        </div>
        <div class="section">
            <table class="table-body">
                <thead>
                    <tr>
                        <th class="bg-primary">ACREDITACIÓN DE LA INVESTIGACIÓN</th>
                    </tr>
                </thead>
                @foreach ($acreditaciones as $item)
                    <tbody>
                        <tr>
                            <th class="roboto-bold-italic">{{ $item->PrimerNombre }}
                                {{ $item->SegundoNombre }}
                                {{ $item->PrimerApellido }} {{ $item->SegundoApellido }}</th>
                        </tr>
                        <tr>
                            <th class="bg-primary text-left">RESUMEN EJECUTIVO DE INVESTIGACIÓN</th>
                        </tr>
                    </tbody>
            </table >
             <div class="border-table">
                   <p class="text-break text-justify"><?php echo strip_tags($item->resumen,"<b><i><br><ul><li>");  ?></p>
             </div>
            <table class="table-body">
                    <tr>
                            <th class="bg-primary text-left">CONCLUSIÓN</th>
                        </tr>
                        <tr>
                            <td class="text-justify"><b><?php echo $item->estado; ?></b></td>
                        </tr>
            </table>

             <div class="border-table">
                   <p class="text-break text-justify"><?php echo strip_tags($item->conclusion,"<b><i><br><ul><li>");  ?></p>
             </div>
             <table class="table-body">
                @endforeach
            </table>
        </div>
        <div class="section">
            <table class="table-body">
                <thead>
                 <tr>
                        <td width="10%">Analista</td>
                        <td width="23%">{{ ucwords(strtolower(optional($analista)->full_name)) }}</td>
                        <td width="10%">Investigador</td>
                        <td width="23%">{{ ucwords(strtolower(optional($investigador)->full_name)) }}</td>
                        <td width="10%">Coordinador</td>
                        <td width="23%">{{ ucwords(strtolower(optional($coordinador)->full_name)) }}</td>
                    </tr>
                    <tr>
                        <td>Gerente del proyecto</td>
                        <td>Gildardo Tijaro Galindo</td>
                        <td colspan="4"><img style="height: 80px; text-align: center;"
                                src="../public/images/firmaGerente.png" /></td>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</body>

</html>
