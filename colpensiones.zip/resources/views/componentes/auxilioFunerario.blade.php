<div class="accordion-item my-2">
    <h2 class="accordion-header" id="auxilioFunerario">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseAuxilioFunerario" aria-expanded="false"
            aria-controls="collapseAuxilioFunerario">
            Auxilio funerario
        </button>
    </h2>
    <div id="collapseAuxilioFunerario" class="accordion-collapse collapse" aria-labelledby="validacionDocumental"
        data-bs-parent="#accordionExample">
        <div class="accordion-body">
            @include('formularios.auxilioFunerario')
        </div>
    </div>
</div>
