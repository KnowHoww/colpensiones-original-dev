<div class="col-12 col-xxl-8 mb-3">
    <h4>Trazabilidad de las actividades realizadas</h4>
    <div class="accordion" id="accordionExample">
        <div class="accordion-item my-2">
            <h2 class="accordion-header" id="trazabilidadActividades">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsetrazabilidadActividades" aria-expanded="true"
                    aria-controls="collapsetrazabilidadActividades">
                    Trazabilidad de las actividades realizadas
                </button>
            </h2>
            <div id="collapsetrazabilidadActividades" class="accordion-collapse collapse"
                aria-labelledby="trazabilidadActividades" data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        @can('excel.informe.trazabilidadActividades')
                            <a href="{{ route('generarInformeTrazabilidadInvestigacion', $investigacion->id) }}"
                                class="d-none d-sm-inline-block btn btn-primary shadow-sm" target="_blank">
                                <i class="fas fa-download fa-sm text-white-50"></i> Descargar trazabilidad
                            </a>
                        @endcan
                    </div>
                    <table class="table datatable table-striped">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th>Usuario</th>
                                <th>Rol</th>
                                <th>Actividad</th>
                                {{-- <th>Fecha</th> --}}
                                <th>Observación</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (count($trazabilidadActividades) > 0)
                                @foreach ($trazabilidadActividades as $actividad)
                                    <tr>
                                        <td>{{ $actividad->creadores->name }} {{ $actividad->creadores->lastname }}</td>
                                        <td>{{ $actividad->rol_usuario }}</td>
                                        <td>{{ $actividad->actividad }}</td>
                                        {{-- <td>{{ $actividad->fecha }}</td> --}}
                                        <td>{{ $actividad->observacion }}</td>
                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="5" class="text-center">No hay datos para mostrar en este momento
                                    </td>
                                </tr>
                            @endif

                        </tbody>
                    </table>
                    @can('trazabilidadActividades.view.formulario')
                        @include('formularios.trazabilidadActividades')
                    @endcan
                </div>
            </div>
        </div>
    </div>
</div>
