<div class="col-12 col-xxl-8 mb-3">
    <h4>Estudios auxiliares (grafología, dactiloscopia, biometría)</h4>
    <div class="accordion" id="accordionExample">
        <div class="accordion-item my-2">
            <h2 class="accordion-header" id="estudiosAuxiliares">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapseestudiosAuxiliares" aria-expanded="true" aria-controls="collapseestudiosAuxiliares">
                    Estudios auxiliares
                </button>
            </h2>
            <div id="collapseestudiosAuxiliares" class="accordion-collapse collapse" aria-labelledby="estudiosAuxiliares"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    @include('formularios.estudiosAuxiliares')
                </div>
            </div>
        </div>
    </div>
</div>
