<div class="accordion-item my-2">
    <h2 class="accordion-header" id="capacidadTrabajo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseCapacidadTrabajo" aria-expanded="true" aria-controls="collapseCapacidadTrabajo">
            Capacidad de trabajo
        </button>
    </h2>
    <div id="collapseCapacidadTrabajo" class="accordion-collapse collapse" aria-labelledby="capacidadTrabajo"
        data-bs-parent="#accordionExample">
        <div class="accordion-body">
            @include('formularios.asignacionPersonal')
        </div>
    </div>
</div>