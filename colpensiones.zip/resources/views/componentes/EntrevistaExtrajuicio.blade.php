<div class="accordion-item my-2">
    <h2 class="accordion-header" id="EntrevistaExtrajuicio">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseEntrevistaExtrajuicio" aria-expanded="true"
            aria-controls="collapseEntrevistaExtrajuicio">
            Entrevista a declarantes extrajuicio
        </button>
    </h2>
    <div id="collapseEntrevistaExtrajuicio" class="accordion-collapse collapse" aria-labelledby="EntrevistaExtrajuicio"
        data-bs-parent="#accordionExample">
        <div class="accordion-body">
            @include('formularios.entrevistaExtrajuicio')
        </div>
    </div>
</div>
