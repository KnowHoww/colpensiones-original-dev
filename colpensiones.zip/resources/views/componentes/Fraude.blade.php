<div class="col-12 col-xxl-8 mb-3">
    <h4>Presunto fraude</h4>
    <div class="accordion" id="accordionExample">
        <div class="accordion-item my-2">
            <h2 class="accordion-header" id="fraude">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsefraude" aria-expanded="true" aria-controls="collapsefraude">
                    Presunto fraude
                </button>
            </h2>
            <div id="collapsefraude" class="accordion-collapse collapse" aria-labelledby="fraude"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    @include('formularios.fraude')
                </div>
            </div>
        </div>
    </div>
</div>
