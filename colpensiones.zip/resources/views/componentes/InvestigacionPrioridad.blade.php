<div class="accordion-item my-2">
    <h2 class="accordion-header" id="investigacionPrioridad">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseinvestigacionPrioridad" aria-expanded="true" aria-controls="collapseinvestigacionPrioridad">
            Prioridad de investigación
        </button>
    </h2>
    <div id="collapseinvestigacionPrioridad" class="accordion-collapse collapse show" aria-labelledby="investigacionPrioridad"
        data-bs-parent="#accordionExample">
        <div class="accordion-body">
            @include('formularios.investigacionPrioridad')
        </div>
    </div>
</div>
