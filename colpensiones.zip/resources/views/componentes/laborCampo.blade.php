<div class="accordion-item my-2">
    <h2 class="accordion-header" id="laborCampo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapselaborCampo" aria-expanded="true" aria-controls="collapselaborCampo">
            Labor de campo
        </button>
    </h2>
    <div id="collapselaborCampo" class="accordion-collapse collapse" aria-labelledby="laborCampo"
        data-bs-parent="#accordionExample">
        <div class="accordion-body">
            @include('formularios.laborCampo')
        </div>
    </div>
</div>