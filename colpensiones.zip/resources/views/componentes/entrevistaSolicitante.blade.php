<div class="accordion-item my-2">
    <h2 class="accordion-header" id="entrevistaSolicitante">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseentrevistaSolicitante" aria-expanded="true" aria-controls="collapseentrevistaSolicitante">
            Entrevista a solicitante
        </button>
    </h2>
    <div id="collapseentrevistaSolicitante" class="accordion-collapse collapse" aria-labelledby="entrevistaSolicitante"
        data-bs-parent="#accordionExample">
        <div class="accordion-body">
            @include('formularios.entrevistaSolicitante')
        </div>
    </div>
</div>