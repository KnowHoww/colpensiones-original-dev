@extends('layouts.app')
@section('content')
    <div>

        <div class="row">
            <div class="col-12">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 alert alert-success">El informe ha sido APROBADO. Se notificará al coordinador. </h1>
                </div>
            </div>
        </div>
       
       
    </div>
@endsection
