<?php

namespace App\Http\Controllers;

use App\Models\TrazabilidadActividadesRealizadas;
use App\Models\Investigaciones;
use App\Models\investigacionesObservacionesEstado;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TrazabilidadActividadesRealizadasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $actividadestipoinvestigacion = json_decode($request->input('actividadestipoinvestigacion'), true);

        $indice = $request->input('actividad');

        if (array_key_exists($indice, $actividadestipoinvestigacion)) {
            $actividadSeleccionada = $actividadestipoinvestigacion[$indice];
        } else {
            return redirect()->back()->with('error', 'Actividad seleccionada no válida.');
        }

        
        $now = Carbon::now(); 
        $investigacion = Investigaciones::findOrFail($request->idInvestigacion);

        $fechaInvestigacion = $investigacion->created_at;

        // $fechaMasAntigua = investigacionesObservacionesEstado::where('idInvestigacion', $request->idInvestigacion)
        //     ->where('idEstado', 5)
        //     ->orderBy('created_at', 'asc')
        //     ->value('created_at');
        
        $fechaMasAntigua  = $investigacion->FechaAprobacion;

        // if (Carbon::parse($request->fecha)->lessThanOrEqualTo($fechaMasAntigua)) {
        //     return redirect()->back()->with('error', 'La fecha de la actividad debe ser mayor a la fecha de asignación de la investigación (' . $fechaMasAntigua->format('Y-m-d') . ').');
        // } elseif (Carbon::parse($request->fecha)->greaterThanOrEqualTo($now)) {
        //     return redirect()->back()->with('error', '¡Alerta del futuro! 🚀 La fecha de la actividad no puede ser después de mañana  (' . $now->format('Y-m-d') . ').¡Viajar en el tiempo no está permitido... todavía! ');
        // }
        $request['idUsuario'] = Auth::user()->id;
        $request['actividad'] = $actividadSeleccionada;
        TrazabilidadActividadesRealizadas::create($request->all());
        return back()->with('info', 'Actividad registrada correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show(TrazabilidadActividadesRealizadas $trazabilidadActividadesRealizadas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TrazabilidadActividadesRealizadas $trazabilidadActividadesRealizadas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    // public function update(Request $request, TrazabilidadActividadesRealizadas $trazabilidadActividadesRealizadas)
    // {
    //     //
    // }
    public function update(Request $request, $id)
    {
        $actividadestipoinvestigacion = json_decode($request->input('actividadestipoinvestigacion'), true);

        $indice = $request->input('actividad');

        if (array_key_exists($indice, $actividadestipoinvestigacion)) {
            $actividadSeleccionada = $actividadestipoinvestigacion[$indice];
        } else {
            return redirect()->back()->with('error', 'Actividad seleccionada no válida.');
        }

        $actividad = TrazabilidadActividadesRealizadas::findOrFail($id);

        // $investigacion = Investigaciones::findOrFail($actividad->idInvestigacion);

        $now = Carbon::now(); 
        // $investigacion = Investigaciones::findOrFail($request->idInvestigacion);

        $fechaMasAntigua = investigacionesObservacionesEstado::where('idInvestigacion', $actividad->idInvestigacion)
            ->where('idEstado', 5)
            ->orderBy('created_at', 'asc')
            ->value('created_at');

        
        if (Carbon::parse($request->fecha)->lessThanOrEqualTo($fechaMasAntigua)) {
            return redirect()->back()->with('error', 'La fecha de la actividad debe ser mayor a la fecha de asignación de la investigación (' . $fechaMasAntigua->format('Y-m-d') . ').');
        } elseif (Carbon::parse($request->fecha)->greaterThanOrEqualTo($now)) {
            return redirect()->back()->with('error', '¡Oops! La fecha de la actividad debe ser antes de mañana  (' . $now->format('Y-m-d') . ') ¡Aún estás a tiempo!.');
        }
        
        $request->validate([
            'actividad' => 'required|string|max:255',
            'observacion' => 'required|string|max:255',
            'fecha' => 'required|date',
        ]);

        $actividad->update([
            'actividad' => $actividadSeleccionada,
            'observacion' => $request->observacion,
            'fecha' => $request->fecha,
        ]);

        return redirect()->back()->with('info', 'Actividad actualizada exitosamente.');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TrazabilidadActividadesRealizadas $trazabilidadActividadesRealizadas)
    {
        //
    }
}
