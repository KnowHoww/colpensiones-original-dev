<?php

namespace App\Http\Controllers;

use App\Models\InvestigacionAcreditacion;
use App\Models\InvestigacionAsignacion;
use App\Models\InvestigacionAuxilioFunerario;
use App\Models\InvestigacionConsultasAntecedentesBeneficiarios;
use App\Models\InvestigacionConsultasAntecedentesCausante;
use App\Models\InvestigacionEntrevistaFamiliares;
use App\Models\InvestigacionEntrevistaSolicitante;
use App\Models\Investigaciones;
use App\Models\InvestigacionesBeneficiarios;
use App\Models\InvestigacionEscolaridad;
use App\Models\investigacionesObservacionesEstado;
use App\Models\InvestigacionEstudiosAuxiliares;
use App\Models\InvestigacionesValidacionDocumentalCausante;
use App\Models\InvestigacionFraude;
use App\Models\InvestigacionGastosVivienda;
use App\Models\InvestigacionLaborCampo;
use App\Models\InvestigacionValidacionDocumentalBeneficiarios;
use App\Models\InvestigacionVerificacion;
use App\Models\Secciones;
use App\Models\SeccionesFormulario;
use App\Models\TrazabilidadActividadesRealizadas;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PDF;

class PDFController extends Controller
{
    public function generarInformeInvestigacionPDF($id, $estado = null)
    {
        // DB::beginTransaction();
        $investigacion = Investigaciones::find($id);
        $facturaAuxilios = [
            [
                'id' => '1',
                'name' => 'Factura de Gastos Funerarios'
            ],
            [
                'id' => '2',
                'name' => 'Contrato Preexequial'
            ],
            [
                'id' => '3',
                'name' => 'Contrato Prenecesidad'
            ],
            [
                'id' => '4',
                'name' => 'Póliza de Seguro'
            ],
            [
                'id' => '0',
                'name' => 'No aplica'
            ],
        ];
        $historialEstados = investigacionesObservacionesEstado::select(
            'investigaciones_observaciones_estados.*',
            'roles.name as rol_usuario'
        )
            ->join('users', 'investigaciones_observaciones_estados.idUsuario', '=', 'users.id')
            ->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->join('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('investigaciones_observaciones_estados.idInvestigacion', $id)
            ->orderBy('id', 'asc')
            ->get();
        $trazabilidadActividades = TrazabilidadActividadesRealizadas::select(
            'investigacion_trazabilidad_actividades_realizadas.*',
            'roles.name as rol_usuario'
        )
            ->join('users', 'investigacion_trazabilidad_actividades_realizadas.idUsuario', '=', 'users.id')
            ->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->join('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('investigacion_trazabilidad_actividades_realizadas.idInvestigacion', $id)
            ->orderBy('fecha', 'asc')
            ->get();
        $beneficiarios = InvestigacionesBeneficiarios::where('IdInvestigacion', $id)->get();
        $entrevistaSolicitante = InvestigacionEntrevistaSolicitante::where('idInvestigacion', $id)->first();
        $esFraude = InvestigacionFraude::where('idInvestigacion', $id)->first();
        $investigacionVerificacion = InvestigacionVerificacion::select('investigacion_verificacion.*', 'investigaciones_beneficiarios.Parentesco', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.TipoDocumento', 'parentesco.nombre as parentesco', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_verificacion.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_verificacion.idBeneficiario')->leftjoin('parentesco', 'parentesco.codigo', 'investigaciones_beneficiarios.Parentesco')->get();
        $acreditaciones = InvestigacionAcreditacion::select('states.name as estado', 'investigacion_acreditacion.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_acreditacion.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_acreditacion.idBeneficiario')->join('states', 'states.id', 'acreditacion')->get();
        $entrevistaFamiliares = InvestigacionEntrevistaFamiliares::where('idInvestigacion', $id)->first();
        $gastosVivienda = InvestigacionGastosVivienda::where('idInvestigacion', $id)->first();
        $auxilioFunerario = InvestigacionAuxilioFunerario::where('idInvestigacion', $id)->first();
        $laborCampo = InvestigacionLaborCampo::where('idInvestigacion', $id)->first();
        $validacionDocumentalCausante = InvestigacionesValidacionDocumentalCausante::where('idInvestigacion', $id)->first();
        $estudioAuxiliar = InvestigacionEstudiosAuxiliares::where('idInvestigacion', $id)->first();
        $validacionDocumentalBeneficiarios = InvestigacionValidacionDocumentalBeneficiarios::select('investigaciones_validacion_documental_beneficiarios.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigaciones_validacion_documental_beneficiarios.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigaciones_validacion_documental_beneficiarios.idBeneficiario')->get();
        $escolaridadBeneficiarios = InvestigacionEscolaridad::select('investigacion_escolaridad.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_escolaridad.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_escolaridad.idBeneficiario')->get();
        $AntecedentesCausante = InvestigacionConsultasAntecedentesCausante::where('idInvestigacion', $id)->first();
        $antecedentesBeneficiarios = InvestigacionConsultasAntecedentesBeneficiarios::select('investigacion_consultas_antecedentes_beneficiarios.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_consultas_antecedentes_beneficiarios.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_consultas_antecedentes_beneficiarios.idBeneficiario')->get();
        $asignacion = InvestigacionAsignacion::where('idInvestigacion', $id)->first();
        $coordinador = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->CoordinadorRegional)->first();
        $investigador = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Investigador)->first();
        $auxiliar = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Auxiliar)->first();
        $analista = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Analista)->first();
        $secciones = SeccionesFormulario::select('secciones.nombre')
            ->join('secciones', 'secciones.id', '=', 'secciones_formularios.Seccion')
            ->where('investigacion', $investigacion->TipoInvestigacion)
            ->get();
        if ($investigacion->cantidadObjeciones>0) {
            $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacionObjecion));
            $estado=16;
        }
        else {
            $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
        }
        
        if ($estado == 7) {
            $nombre = 'DJT-INF-AD-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '.pdf';
        } else {
            $nombre = 'DJT-INF-AD-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '_' . $investigacion->cantidadObjeciones . '.pdf';
        }
        $pdf = PDF::loadView('informes.informePDF', compact('secciones', 'investigacion', 'asignacion', 'beneficiarios', 'validacionDocumentalCausante', 'validacionDocumentalBeneficiarios', 'AntecedentesCausante', 'antecedentesBeneficiarios', 'historialEstados', 'trazabilidadActividades', 'entrevistaSolicitante', 'facturaAuxilios', 'auxilioFunerario', 'gastosVivienda', 'laborCampo', 'entrevistaFamiliares', 'escolaridadBeneficiarios', 'acreditaciones', 'coordinador', 'investigador', 'auxiliar', 'analista', 'investigacionVerificacion', 'esFraude', 'estudioAuxiliar', 'nombre'));
        $pdf->setPaper('letter', 'portrait')->render();
        $continuar = false;
        switch ($estado) {
            case '7':
                $rutaDirectorio = 'investigaciones/finalizados/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
                
                $continuar = true;
                break;
            case '16':
                $rutaDirectorio = 'investigaciones/finalizadosObjetados/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
                $continuar = true;
                break;
        }
        if ($continuar) {
            $rutaDirectorioRadicado = 'investigaciones/radicado/' . $investigacion->nombreCarpeta;

            $rutaArchivo = $rutaDirectorio . '/' . $nombre;
            $rutaArchivoRadicado = $rutaDirectorioRadicado . '/investigacion/' . $nombre;

            $ruta = 'investigaciones/radicado/' . $investigacion->nombreCarpeta . '/investigacion';

            if (!Storage::exists($ruta)) {
                Storage::makeDirectory($ruta);
            }

            if (!Storage::exists($rutaDirectorio)) {
                Storage::makeDirectory($rutaDirectorio);
            }
            if (!file_exists(storage_path('app/' . $rutaArchivo))) {
                $pdf->save(storage_path('app/' . $rutaArchivo));
                $pdf->save(storage_path('app/' . $rutaArchivoRadicado));
            }
            return $pdf->stream($nombre);
        }
    }

    public function generarInformeInvestigacionSoportesPDF($id)
    {
        $investigacion = Investigaciones::find($id);
        $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
        $nombreArchivo = 'GRP-IAD-PR-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '_0.pdf';
        $documentos = Storage::disk('investigaciones')->allFiles('radicado/' . $investigacion->nombreCarpeta . '/soporteFotografico');
        $pdf = PDF::loadView('informes.informeSoportesPDF', compact('documentos', 'nombreArchivo'));

        $pdf->setPaper('letter', 'portrait')->render();

        $ruta = 'investigaciones/radicado/' . $investigacion->nombreCarpeta . '/soporteFotografico/';

        if (!Storage::exists($ruta)) {
            Storage::makeDirectory($ruta);
        }
        $estado = $investigacion->estado;
        if ($estado==7 && $investigacion->cantidadObjeciones>0)
        {
            $estado==16;
        }
        switch ($estado) {
            case '7':
                $rutaDirectorio = 'investigaciones/finalizados/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
                $continuar = true;
                break;
            case '16':
                $rutaDirectorio = 'investigaciones/finalizadosObjetados/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
                $continuar = true;
                break;
        }
        //$rutaDirectorio = 'investigaciones/finalizados/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;

        $rutaArchivo = $rutaDirectorio . '/' . $nombreArchivo;

        if (!Storage::exists($rutaDirectorio)) {
            Storage::makeDirectory($rutaDirectorio);
        }

        // Guardar el archivo PDF en las rutas especificadas
        $pdf->save(storage_path('app/' . $rutaArchivo));

        return true;
    }

    public function generarInformeInvestigacionSoportesPreview($id)
    {
        // DB::beginTransaction();
        $investigacion = Investigaciones::find($id);
        $nombre = 'GRP-INF-AD-' . $investigacion->NumeroRadicacionCaso . '_' . date('Ymd') . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '.pdf';
        $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
        $nombreArchivo = 'GRP-IAD-PR-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '_0.pdf';
        $documentos = Storage::disk('investigaciones')->allFiles('radicado/' . $investigacion->nombreCarpeta . '/soporteFotografico');
        $pdf = PDF::loadView('informes.informeSoportesPDF', compact('documentos', 'nombreArchivo'));

        return $pdf->stream($nombre);


        return true;
    }

    public function verInformePdfFinal($id)
    {
        $investigacion = Investigaciones::find($id);
        if ($investigacion->esObjetado == 0) {
            $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
            $url = "/investigaciones/radicado/" . $investigacion->nombreCarpeta . "/investigacion/DJT-INF-AD-" . $investigacion->CasoPadreOriginal . "_" . $fechaFormateada . "_" . $investigacion->TipoDocumento . "_" . $investigacion->NumeroDeDocumento . "_" . $investigacion->id . ".pdf";
        } else {
            $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacionObjecion));
            $url = "/investigaciones/radicado/" . $investigacion->nombreCarpeta . "/investigacion/DJT-INF-AD-" . $investigacion->CasoPadreOriginal . "_" . $fechaFormateada . "_" . $investigacion->TipoDocumento . "_" . $investigacion->NumeroDeDocumento . "_" . $investigacion->id . '_' . $investigacion->cantidadObjeciones . ".pdf";
        }

        if (!file_exists($url)) {
            return $this->generarInformeInvestigacionPDF($id, $investigacion->estado);
        }

        return $url;
    }

    public function verInformePdfFinalPreview($id)
    {
        // DB::beginTransaction();
        $investigacion = Investigaciones::find($id);
        $facturaAuxilios = [
            [
                'id' => '1',
                'name' => 'Factura de Gastos Funerarios'
            ],
            [
                'id' => '2',
                'name' => 'Contrato Preexequial'
            ],
            [
                'id' => '3',
                'name' => 'Contrato Prenecesidad'
            ],
            [
                'id' => '4',
                'name' => 'Póliza de Seguro'
            ],
            [
                'id' => '0',
                'name' => 'No aplica'
            ],
        ];
        $historialEstados = investigacionesObservacionesEstado::select(
            'investigaciones_observaciones_estados.*',
            'roles.name as rol_usuario'
        )
            ->join('users', 'investigaciones_observaciones_estados.idUsuario', '=', 'users.id')
            ->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->join('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('investigaciones_observaciones_estados.idInvestigacion', $id)
            ->orderBy('id', 'asc')
            ->get();
        $trazabilidadActividades = TrazabilidadActividadesRealizadas::select(
            'investigacion_trazabilidad_actividades_realizadas.*',
            'roles.name as rol_usuario'
        )
            ->join('users', 'investigacion_trazabilidad_actividades_realizadas.idUsuario', '=', 'users.id')
            ->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->join('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('investigacion_trazabilidad_actividades_realizadas.idInvestigacion', $id)
            ->orderBy('fecha', 'asc')
            ->get();
        $nombre = 'informePreview.pdf';
        $beneficiarios = InvestigacionesBeneficiarios::where('IdInvestigacion', $id)->get();
        $entrevistaSolicitante = InvestigacionEntrevistaSolicitante::where('idInvestigacion', $id)->first();
        $esFraude = InvestigacionFraude::where('idInvestigacion', $id)->first();
        $investigacionVerificacion = InvestigacionVerificacion::select('investigacion_verificacion.*', 'investigaciones_beneficiarios.Parentesco', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.TipoDocumento', 'parentesco.nombre as parentesco', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_verificacion.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_verificacion.idBeneficiario')->leftjoin('parentesco', 'parentesco.codigo', 'investigaciones_beneficiarios.Parentesco')->get();
        $acreditaciones = InvestigacionAcreditacion::select('states.name as estado', 'investigacion_acreditacion.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_acreditacion.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_acreditacion.idBeneficiario')->join('states', 'states.id', 'acreditacion')->get();
        $entrevistaFamiliares = InvestigacionEntrevistaFamiliares::where('idInvestigacion', $id)->first();
        $gastosVivienda = InvestigacionGastosVivienda::where('idInvestigacion', $id)->first();
        $auxilioFunerario = InvestigacionAuxilioFunerario::where('idInvestigacion', $id)->first();
        $laborCampo = InvestigacionLaborCampo::where('idInvestigacion', $id)->first();
        $validacionDocumentalCausante = InvestigacionesValidacionDocumentalCausante::where('idInvestigacion', $id)->first();
        $estudioAuxiliar = InvestigacionEstudiosAuxiliares::where('idInvestigacion', $id)->first();
        $validacionDocumentalBeneficiarios = InvestigacionValidacionDocumentalBeneficiarios::select('investigaciones_validacion_documental_beneficiarios.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigaciones_validacion_documental_beneficiarios.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigaciones_validacion_documental_beneficiarios.idBeneficiario')->get();
        $escolaridadBeneficiarios = InvestigacionEscolaridad::select('investigacion_escolaridad.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_escolaridad.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_escolaridad.idBeneficiario')->get();
        $AntecedentesCausante = InvestigacionConsultasAntecedentesCausante::where('idInvestigacion', $id)->first();
        $antecedentesBeneficiarios = InvestigacionConsultasAntecedentesBeneficiarios::select('investigacion_consultas_antecedentes_beneficiarios.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_consultas_antecedentes_beneficiarios.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_consultas_antecedentes_beneficiarios.idBeneficiario')->get();
        $asignacion = InvestigacionAsignacion::where('idInvestigacion', $id)->first();
        $coordinador = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->CoordinadorRegional)->first();
        $investigador = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Investigador)->first();
        $auxiliar = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Auxiliar)->first();
        $analista = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Analista)->first();
        $secciones = SeccionesFormulario::select('secciones.nombre')
            ->join('secciones', 'secciones.id', '=', 'secciones_formularios.Seccion')
            ->where('investigacion', $investigacion->TipoInvestigacion)
            ->get();
        $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
        $pdf = PDF::loadView('informes.informePDF', compact('secciones', 'investigacion', 'asignacion', 'beneficiarios', 'validacionDocumentalCausante', 'validacionDocumentalBeneficiarios', 'AntecedentesCausante', 'antecedentesBeneficiarios', 'historialEstados', 'trazabilidadActividades', 'entrevistaSolicitante', 'facturaAuxilios', 'auxilioFunerario', 'gastosVivienda', 'laborCampo', 'entrevistaFamiliares', 'escolaridadBeneficiarios', 'acreditaciones', 'coordinador', 'investigador', 'auxiliar', 'analista', 'investigacionVerificacion', 'esFraude', 'estudioAuxiliar', 'nombre'));
        $pdf->setPaper('letter', 'portrait')
            ->setOption('margin-top', 30)
            ->setOption('margin-bottom', 30)
            ->setOption('margin-left', 15)
            ->setOption('margin-right', 15);

        return $pdf->stream('informePreview.pdf');
    }

    public function generarInformeInvestigacionSoportesPDF2($id)
    {
        $investigacion = Investigaciones::find($id);
        $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
        $nombreArchivo = 'GRP-IAD-PR-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '_0.pdf';
        $documentos = Storage::disk('investigaciones')->allFiles('radicado/' . $investigacion->nombreCarpeta . '/soporteFotografico');
        $pdf = PDF::loadView('informes.informeSoportesPDF', compact('documentos', 'nombreArchivo'));

        $pdf->setPaper('letter', 'portrait')->render();

        $rutaDirectorio = 'investigaciones/nuevas_finalizadas/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
        $rutaArchivo = $rutaDirectorio . '/' . $nombreArchivo;

        if (!Storage::exists($rutaDirectorio)) {
            Storage::makeDirectory($rutaDirectorio);
        }

        // Guardar el archivo PDF en la ruta especificada
        $pdf->save(storage_path('app/' . $rutaArchivo));

        return true;
    }

    public function generarInformeInvestigacionPDF2($id, $estado = null)
    {
        // DB::beginTransaction();
        $investigacion = Investigaciones::find($id);
        $facturaAuxilios = [
            [
                'id' => '1',
                'name' => 'Factura de Gastos Funerarios'
            ],
            [
                'id' => '2',
                'name' => 'Contrato Preexequial'
            ],
            [
                'id' => '3',
                'name' => 'Contrato Prenecesidad'
            ],
            [
                'id' => '4',
                'name' => 'Póliza de Seguro'
            ],
            [
                'id' => '0',
                'name' => 'No aplica'
            ],
        ];
        $historialEstados = investigacionesObservacionesEstado::select(
            'investigaciones_observaciones_estados.*',
            'roles.name as rol_usuario'
        )
            ->join('users', 'investigaciones_observaciones_estados.idUsuario', '=', 'users.id')
            ->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->join('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('investigaciones_observaciones_estados.idInvestigacion', $id)
            ->orderBy('id', 'asc')
            ->get();
        $trazabilidadActividades = TrazabilidadActividadesRealizadas::select(
            'investigacion_trazabilidad_actividades_realizadas.*',
            'roles.name as rol_usuario'
        )
            ->join('users', 'investigacion_trazabilidad_actividades_realizadas.idUsuario', '=', 'users.id')
            ->join('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->join('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('investigacion_trazabilidad_actividades_realizadas.idInvestigacion', $id)
            ->orderBy('fecha', 'asc')
            ->get();
        $beneficiarios = InvestigacionesBeneficiarios::where('IdInvestigacion', $id)->get();
        $entrevistaSolicitante = InvestigacionEntrevistaSolicitante::where('idInvestigacion', $id)->first();
        $esFraude = InvestigacionFraude::where('idInvestigacion', $id)->first();
        $investigacionVerificacion = InvestigacionVerificacion::select('investigacion_verificacion.*', 'investigaciones_beneficiarios.Parentesco', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.TipoDocumento', 'parentesco.nombre as parentesco', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_verificacion.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_verificacion.idBeneficiario')->leftjoin('parentesco', 'parentesco.codigo', 'investigaciones_beneficiarios.Parentesco')->get();
        $acreditaciones = InvestigacionAcreditacion::select('states.name as estado', 'investigacion_acreditacion.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_acreditacion.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_acreditacion.idBeneficiario')->join('states', 'states.id', 'acreditacion')->get();
        $entrevistaFamiliares = InvestigacionEntrevistaFamiliares::where('idInvestigacion', $id)->first();
        $gastosVivienda = InvestigacionGastosVivienda::where('idInvestigacion', $id)->first();
        $auxilioFunerario = InvestigacionAuxilioFunerario::where('idInvestigacion', $id)->first();
        $laborCampo = InvestigacionLaborCampo::where('idInvestigacion', $id)->first();
        $validacionDocumentalCausante = InvestigacionesValidacionDocumentalCausante::where('idInvestigacion', $id)->first();
        $estudioAuxiliar = InvestigacionEstudiosAuxiliares::where('idInvestigacion', $id)->first();
        $validacionDocumentalBeneficiarios = InvestigacionValidacionDocumentalBeneficiarios::select('investigaciones_validacion_documental_beneficiarios.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigaciones_validacion_documental_beneficiarios.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigaciones_validacion_documental_beneficiarios.idBeneficiario')->get();
        $escolaridadBeneficiarios = InvestigacionEscolaridad::select('investigacion_escolaridad.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_escolaridad.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_escolaridad.idBeneficiario')->get();
        $AntecedentesCausante = InvestigacionConsultasAntecedentesCausante::where('idInvestigacion', $id)->first();
        $antecedentesBeneficiarios = InvestigacionConsultasAntecedentesBeneficiarios::select('investigacion_consultas_antecedentes_beneficiarios.*', 'investigaciones_beneficiarios.NumeroDocumento', 'investigaciones_beneficiarios.PrimerNombre', 'investigaciones_beneficiarios.SegundoNombre', 'investigaciones_beneficiarios.PrimerApellido', 'investigaciones_beneficiarios.SegundoApellido')->where('investigacion_consultas_antecedentes_beneficiarios.idInvestigacion', $id)->join('investigaciones_beneficiarios', 'investigaciones_beneficiarios.id', 'investigacion_consultas_antecedentes_beneficiarios.idBeneficiario')->get();
        $asignacion = InvestigacionAsignacion::where('idInvestigacion', $id)->first();
        $coordinador = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->CoordinadorRegional)->first();
        $investigador = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Investigador)->first();
        $auxiliar = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Auxiliar)->first();
        $analista = User::selectRaw('id, CONCAT(users.name, " ", users.lastname) as full_name')->where('id', $asignacion->Analista)->first();
        $secciones = SeccionesFormulario::select('secciones.nombre')
            ->join('secciones', 'secciones.id', '=', 'secciones_formularios.Seccion')
            ->where('investigacion', $investigacion->TipoInvestigacion)
            ->get();
        $fechaFormateada = date('Ymd', strtotime($investigacion->FechaFinalizacion));
        if ($estado == 7) {
            $nombre = 'DJT-INF-AD-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '.pdf';
        } else {
            $nombre = 'DJT-INF-AD-' . $investigacion->CasoPadreOriginal . '_' . $fechaFormateada . '_' . $investigacion->TipoDocumento . '_' . $investigacion->NumeroDeDocumento . '_' . $investigacion->id . '_' . $investigacion->cantidadObjeciones . '.pdf';
        }
        $pdf = PDF::loadView('informes.informePDF', compact('secciones', 'investigacion', 'asignacion', 'beneficiarios', 'validacionDocumentalCausante', 'validacionDocumentalBeneficiarios', 'AntecedentesCausante', 'antecedentesBeneficiarios', 'historialEstados', 'trazabilidadActividades', 'entrevistaSolicitante', 'facturaAuxilios', 'auxilioFunerario', 'gastosVivienda', 'laborCampo', 'entrevistaFamiliares', 'escolaridadBeneficiarios', 'acreditaciones', 'coordinador', 'investigador', 'auxiliar', 'analista', 'investigacionVerificacion', 'esFraude', 'estudioAuxiliar', 'nombre'));
        $pdf->setPaper('letter', 'portrait')->render();
        $continuar = false;
        switch ($estado) {
            case '7':
                $rutaDirectorio = 'investigaciones/nuevas_finalizadas/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
                $continuar = true;
                break;
            case '16':
                $rutaDirectorio = 'investigaciones/nuevas_finalizadas/finalizadosObjetados/' . $investigacion->CasoPadreOriginal . '_' . $investigacion->id;
                $continuar = true;
                break;
        }
        if ($continuar) {
            $rutaDirectorioRadicado = 'investigaciones/nuevas_finalizadas/' . $investigacion->nombreCarpeta;
            var_dump($rutaDirectorioRadicado);
            $rutaArchivo = $rutaDirectorio . '/' . $nombre;
            var_dump($rutaArchivo);
            $rutaArchivoRadicado = $rutaDirectorioRadicado . '/' .$nombre;
            var_dump($rutaArchivoRadicado);

            // if (!Storage::exists($rutaDirectorioRadicado)) {
            //     Storage::makeDirectory($rutaDirectorioRadicado);
            // }
            if (!Storage::exists($rutaDirectorio)) {
                Storage::makeDirectory($rutaDirectorio);
            }
            if (!file_exists(storage_path('app/' . $rutaArchivo))) {
                $pdf->save(storage_path('app/' . $rutaArchivo));
                // $pdf->save(storage_path('app/' . $rutaArchivoRadicado));
            }
            return $pdf->stream($nombre);
        }
    }



    public function verinformeInvestigadorpdf(string $id ,string $periodo1 , string $periodo2)
    {
        
          $sql = 'SELECT   UCASE(CONCAT_WS(\' \' , NAME ,lastname )) AS nombres, numberDocument AS identificacion FROM users ' .
                'WHERE id = ' . $id ;

            $periodo = $periodo1 . ' a ' . $periodo2;
        
        
           $sql2 = 'select investigaciones.id AS idInvestigacion, ' .
                'investigaciones.NumeroRadicacionCaso, ' .
                'tipo_investigacion.nombre AS tipoInvestigacion, ' .
                'investigaciones_comision.porBeneficiario '.
                'FROM investigaciones LEFT JOIN ' .
                'tipo_investigacion ON investigaciones.TipoInvestigacion = tipo_investigacion.codigo LEFT JOIN ' .
                'investigacion_asignacion ON investigacion_asignacion.idInvestigacion = investigaciones.id LEFT JOIN ' .
                'investigaciones_comision ON investigaciones_comision.idInvestigacion = investigaciones.id LEFT JOIN ' .
                'investigaciones_facturacion ON investigaciones.id = investigaciones_facturacion.idInvestigacion LEFT JOIN ' .
                'users as Investigador  ON Investigador.id = investigacion_asignacion.Investigador  ' .
                'WHERE   not investigaciones_facturacion.FechaFacturacion is NULL and   Investigador.id =  ' . $id  .' and  Investigaciones.FechaFinalizacion between  \'' . $periodo1 . '\' and DATE_ADD(\'' . $periodo2 . '\', INTERVAL 1 DAY) ' . 
                ' group by tipoInvestigacion , investigaciones.NumeroRadicacionCaso ,  investigaciones.id  order by tipoInvestigacion  ' ;
        
         $sql3 = 'select   tipo_investigacion.nombre AS tipoInvestigacion, count(*) as cantidad ' .
                'FROM investigaciones LEFT JOIN ' .
                'tipo_investigacion ON investigaciones.TipoInvestigacion = tipo_investigacion.codigo LEFT JOIN ' .
                'investigacion_asignacion ON investigacion_asignacion.idInvestigacion = investigaciones.id LEFT JOIN ' .
                'investigaciones_facturacion ON investigaciones.id = investigaciones_facturacion.idInvestigacion LEFT JOIN ' .
                'users as Investigador  ON Investigador.id = investigacion_asignacion.Investigador LEFT JOIN   ' .
                'users as Auxiliar  ON Investigador.id = investigacion_asignacion.Auxiliar  ' .
                'WHERE   not investigaciones_facturacion.FechaFacturacion is NULL and ( Investigador.id =  ' . $id  .' or Auxiliar.id =  ' . $id  .' ) and  Investigaciones.FechaFinalizacion between \'' . $periodo1 . '\' and DATE_ADD(\'' . $periodo2 . '\', INTERVAL 1 DAY) ' .
                ' group by tipoInvestigacion  order by tipoInvestigacion ' ;
        
        
        
           $sql4 = 'select investigaciones.id AS idInvestigacion, ' .
                'investigaciones.NumeroRadicacionCaso, ' .
                'tipo_investigacion.nombre AS tipoInvestigacion ' .
                
                'FROM investigaciones LEFT JOIN ' .
                'tipo_investigacion ON investigaciones.TipoInvestigacion = tipo_investigacion.codigo LEFT JOIN ' .
                'investigacion_asignacion ON investigacion_asignacion.idInvestigacion = investigaciones.id LEFT JOIN ' .
                'investigaciones_facturacion ON investigaciones.id = investigaciones_facturacion.idInvestigacion LEFT JOIN ' .
                'users as Investigador  ON Investigador.id = investigacion_asignacion.Auxiliar  ' .
                'WHERE   not investigaciones_facturacion.FechaFacturacion is NULL and   Investigador.id =  ' . $id  .' and  Investigaciones.FechaFinalizacion between  \'' . $periodo1 . '\' and DATE_ADD(\'' . $periodo2 . '\', INTERVAL 1 DAY) ' . 
                ' group by tipoInvestigacion , investigaciones.NumeroRadicacionCaso ,  investigaciones.id  order by tipoInvestigacion  ' ;
        
        
        
        $contratista = collect(DB::Select($sql))->first();;
        $datos = DB::Select($sql3);
        $investigaciones = DB::Select($sql2);
        $apoyos = DB::Select($sql4);
        


        $pdf = PDF::loadView('informes.informeInvestigadorPDF', compact('contratista', 'datos', 'investigaciones', 'apoyos', 'periodo'));
        $pdf->setPaper('letter', 'portrait')->render();
            $rutaArchivo = 'informeInvestigador' . $id. '-' . $periodo .'.pdf' ;

            
            return $pdf->stream($rutaArchivo);

    }

}
