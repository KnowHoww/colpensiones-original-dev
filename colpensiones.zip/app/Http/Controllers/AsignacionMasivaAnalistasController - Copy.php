<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

// Imports
use App\Imports\AsignacionAnalistasImport;
use App\Imports\AsignacionAnalistasCambioEstadoImport;

// Export para errores
use App\Exports\ErroresImportacionExport;

class AsignacionMasivaAnalistasController extends Controller
{
    public function index()
    {
        // Vista con el formulario
        return view('asignacionmasivaanalistas.index');
    }
    public function import(Request $request)
    {
        // 1) Validar que sea un archivo Excel
        $request->validate([
            'tipo_archivo' => 'required|in:solo_asignacion,asignacion_cambio',
            'file'         => 'required|file|mimes:xlsx,xls,csv',
        ]);

        $tipoArchivo = $request->input('tipo_archivo');
        $file        = $request->file('file');

        // 2) Instanciar el import correspondiente
        if ($tipoArchivo === 'solo_asignacion') {
            $import = new AsignacionAnalistasImport;
        } else {
            $import = new AsignacionAnalistasCambioEstadoImport;
        }

        // 3) Ejecutamos la importación en un try/catch por si algo fatal ocurre
        try {
            Excel::import($import, $file);

            // 4) Revisamos errores de filas
            $errores = method_exists($import, 'getErrores') ? $import->getErrores() : [];

            if (count($errores) > 0) {
                // Existen filas con problemas -> generamos un Excel para su descarga
                $nombreArchivo = 'errores_importacion_'.date('YmdHis').'.xlsx';
                
                // Generamos y retornamos la descarga
                return Excel::download(new ErroresImportacionExport($errores), $nombreArchivo);
            }

            // Si llegamos aquí, no hubo errores
            return redirect()->back()->with('success', 'La importación se realizó correctamente (sin errores).');

        } catch (\Exception $e) {
            // Este catch atrapa errores globales (por ej., archivo corrupto, etc.)
            return redirect()->back()->with('error', 'Error al procesar el archivo: '.$e->getMessage());
        }
    }
}
